package com.testleaf.testcases;

import org.openqa.selenium.StaleElementReferenceException;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 1;
		
		int[] nums = {10, 20, 30};
		
		try {
			System.out.println(a/b);
			System.out.println(nums[2]);
		} catch(ArithmeticException e) {
//			System.out.println(e);
			if(b==0) {
				System.out.println(a/1);
			}
		} catch (ArrayIndexOutOfBoundsException  e) {
			System.out.println(e);
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Finally");
		}
		
		System.out.println("Last line");
	}

}
