package com.testleaf.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.testleaf.utils.ReadExcel;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecificMethods {

	public RemoteWebDriver driver;
	public String fileName;
	public static Properties prop1;
	
	public static ExtentReports extent;
	public ExtentTest test, node;
	
	public String testName, testDescription, testAuthor, testCategory; // null
	
    @BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}
    
    @BeforeClass
    public void testCaseDetails() {
    	test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);

	}
    
    public int takeSnap() throws IOException {
    	int ranNum = (int) (Math.random()*9999999+1000000);
    	
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/img"+ranNum+".png"); //img3789562.png
		FileUtils.copyFile(source, target);

		return ranNum; //3789562
	}
    
    public void reportStep(String stepDesc, String status) throws IOException {
		if(status.equalsIgnoreCase("pass")) {												 //3789562	
			node.pass(stepDesc,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			node.fail(stepDesc,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			throw new RuntimeException("See the Extent Report for failure log");
		}

	}
    
    
    @AfterSuite
    public void stopReport() {
    	extent.flush();

	}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

	@Parameters("browser")
	@BeforeMethod
	public void preCondition(@Optional("chrome") String browser) throws IOException {
		
		node = test.createNode(testName);
		
		
		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/config.properties"));
		prop.load(fis);
		String url = prop.getProperty("url");
		driver.get(url);
		String lang = prop.getProperty("lang");
		prop1 = new Properties();
		FileInputStream fis1 = new FileInputStream(new File("./src/main/resources/" + lang + ".properties"));
		prop1.load(fis1);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider(name = "getData")
	public String[][] fetchData() throws IOException {
		return ReadExcel.readData(fileName);
	}
}
