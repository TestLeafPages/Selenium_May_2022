package com.testleaf.testcases;

public class LearnThrows {

	public static void main(String[] args) {
		LearnThrows lt = new LearnThrows();
		lt.sleep(1000);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			System.out.println("Element not found");
			throw new RuntimeException();
		}
	}
	
	public void sleep(int mSecs) {
		try {
			Thread.sleep(mSecs);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
