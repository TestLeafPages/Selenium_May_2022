package com.testleaf.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testleaf.base.ProjectSpecificMethods;
import com.testleaf.pages.LoginPage;

public class TC002CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setData() {
		fileName = "TC001Login";
		testName = "TC002CreateLead";
		testDescription ="Create Lead with mandatory info";
		testAuthor = "Haja";
		testCategory = "Functional";

	}

	@Test
	public void runCreateLead() throws IOException {
		new LoginPage(driver)
		.enterUserName("DemoSalesManager")
		.enterPassword("crmsfa")
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLead();
	}
}
