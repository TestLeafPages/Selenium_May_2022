package com.testleaf.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {

	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
		
		// Setup file name
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/config.properties"));
		
		// Load this file
		prop.load(fis);
		
		// Read the data
		String url = prop.getProperty("url");
		System.out.println(url);
		System.out.println(prop.getProperty("browser"));
	}

}
