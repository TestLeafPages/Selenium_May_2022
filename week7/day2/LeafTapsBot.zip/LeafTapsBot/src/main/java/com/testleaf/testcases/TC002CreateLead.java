package com.testleaf.testcases;

import org.testng.annotations.Test;

import com.testleaf.base.ProjectSpecificMethods;
import com.testleaf.pages.LoginPage;

public class TC002CreateLead extends ProjectSpecificMethods{

	@Test
	public void runCreateLead() {
		new LoginPage(driver)
		.enterUserName("DemoSalesManager")
		.enterPassword("crmsfa")
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLead();
	}
}
