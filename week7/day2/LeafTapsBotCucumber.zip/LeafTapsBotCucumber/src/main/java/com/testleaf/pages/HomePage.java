package com.testleaf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.testleaf.base.ProjectSpecificMethods;

import io.cucumber.java.en.Given;

public class HomePage extends ProjectSpecificMethods {
	
//	public HomePage(RemoteWebDriver driver) {
//		this.driver = driver;
//	}
	

	public MyHomePage clickCRMSFA() {
		
		return new MyHomePage();
	}
	
	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}
	
	@Given("Homepage should be displayed")
	public HomePage verifyLoginSuccess() {
		System.out.println("Login success");
		return this;
	}
}
