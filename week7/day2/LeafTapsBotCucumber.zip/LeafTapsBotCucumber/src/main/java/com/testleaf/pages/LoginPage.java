package com.testleaf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.testleaf.base.ProjectSpecificMethods;

import io.cucumber.java.en.Given;

public class LoginPage extends ProjectSpecificMethods{
	
//	public LoginPage(RemoteWebDriver driver) {
//		this.driver = driver;
//	}
	
	@Given("Enter the username {string}")
	public LoginPage enterUserName(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}
	
	@Given("Enter the password {string}")
	public LoginPage enterPassword(String pwd) {
		getDriver().findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	
	@Given("Click on Login button")
	public HomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}

}
